    <?php

    define("W_NAME", "SITE TITLE");

    define("W_ROOT", "http://example.com/");
    define("F_ROOT", "var/www/html/app");

    define("W_CSS",    W_ROOT  . "css/");
    define("F_CSS",    F_ROOT  . "css/");

    define("W_JS",     W_ROOT  . "js/");
    define("F_JS",     F_ROOT  . "js/");

    define("W_INCS",   W_ROOT  . "includes/");
    define("F_INCS",   F_ROOT  . "includes/");

    define("F_LIB",    F_INCS  . "lib/");

    define("W_PARTS",  W_ROOT  . "parts/");
    define("F_PARTS",  F_ROOT  . "parts/");

    define("W_IMG",    W_ROOT  . "images/");
    define("F_IMG",    F_ROOT  . "images/");

    define("W_UPLOAD", W_ROOT . "uploads/");
    define("F_UPLOAD", F_ROOT . "uploads/");

    define("DBTYPE", "DBTYPE");
    define("DBHOST", "DBHOST");
    define("DBUSER", "DBUSER");
    define("DBPASS", "DBPASS");
    define("DBNAME", "DBNAME");

    # Display errors
    error_reporting(E_ERROR);

    # Include the needed files
    require_once(F_LIB . "Database.class.php");
    require_once(F_LIB . "Utils.class.php");
    require_once(F_LIB . "User.class.php");

    # Create the needed objects
    global $global;
    $global->db               = Database::getConnection();
    $user_obj                 = new User();
    $global->languageIniArray = parse_ini_file(F_INCS . "language.ini");

    # Start the session
    if (strlen(session_id()) < 1) {
        session_start();
    }

    ob_start();

    # Define the Global variables that can be used in entire project.
    $global->isLogged                    = $user_obj->checkLogin();