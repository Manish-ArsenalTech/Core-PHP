<?php

/**
 * Class User
 */
class User
{

    /**
     * @var
     */
    protected $_db;

    /**
     * User constructor.
     */
    public function __construct()
    {
        global $global;
        $this->_db = $global->db;
    }

    /**
     * Get All Users.
     * @param array $data
     * @return bool
     */
    public function getAll($data = array())
    {
        $sql_array = array();
        $page      = !empty($data['page']) ? (int)$data['page'] : 1;
        $perpage   = !empty($data['perpage']) ? (int)$data['perpage'] : 150;
        $start     = ($page - 1) * $perpage;

        $sql
             = "SELECT user.*,
                FROM user
                ORDER BY user.user_id DESC
                Limit $start, $perpage";
        $stm = $this->_db->prepare($sql);
        try {
            $stm->execute($sql_array);
            $rows = $stm->fetchAll(PDO::FETCH_OBJ);
            return $rows;
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Get User details by id.
     * @param $user_id
     * @return bool
     */
    public function getById($user_id)
    {
        $sql = "SELECT *, COUNT(user_id) AS count FROM user WHERE user_id = :user_id";
        $stm = $this->_db->prepare($sql);

        $stm->bindParam(":user_id", $user_id);
        $res = $stm->execute();
        if ($res) {
            $row = $stm->fetch(PDO::FETCH_ASSOC);
            return $row['count'] > 0 ? $row : false;
        } else {
            return false;
        }
    }

    /**
     * Add/Update User, based on given data.
     * @param $post_data
     * @return bool
     */
    public function save($post_data)
    {
        global $global;
        if ($post_data['user_id'] > 0) {
            if ($post_data['user_type']) {
                $sql_array = array(':user_id' => $post_data['user_id'], ':name' => $post_data['name'], ':user_type' => $post_data['user_type']);
                $sql       = "UPDATE user SET name = :name, cron_activation = '1', user_type = :user_type WHERE user_id = :user_id";
            } else {
                $sql_array = array(':user_id' => $post_data['user_id'], ':name' => $post_data['name']);
                $sql       = "UPDATE user SET name = :name, cron_activation = '1' WHERE user_id = :user_id";
            }
        } else {

        }

        $stm = $this->_db->prepare($sql);

        try {
            $res = $stm->execute($sql_array);
        } catch (PDOException $e) {
            return false;
        }

        if ($res) {
            $_SESSION['notifications'][] = array('type' => 'success', 'msg' => $global->languageIniArray['user_edit_suucess_msg']);
        } else {
            $_SESSION['notifications'][] = array('type' => 'error', 'msg' => $global->languageIniArray['common_error_msg']);
        }
        session_regenerate_id(true);
        header('Location: ' . W_ROOT . 'users.php');
        session_write_close();
    }

    /**
     * Delete User.
     * @param $post_data
     * @return bool
     */
    public function delete($post_data)
    {
        $sql_array = array(':user_id' => $post_data['user_id']);
        $sql       = "DELETE FROM user WHERE user_id = :user_id";
        $stm       = $this->_db->prepare($sql);

        try {
            $res = $stm->execute($sql_array);
        } catch (PDOException $e) {
            return false;
        }

        return $res;
    }

}