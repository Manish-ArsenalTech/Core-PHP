<?php

/**
 * Class Utils
 * Class containing utility functions that can be used throughout the application.
 */
class Utils
{

    /**
     * Apply Trimming on values of Array.
     * @param $input
     * @return bool
     */
    public static function tidyPostValues($input)
    {
        $output = false;
        if (!is_array($input)) {
            return $output;
        }
        foreach ($input AS $key => $val) {
            if (is_array($val)) {
                $output[$key] = self::tidyPostValues($val);
            } else {
                $output[$key] = trim($val);
            }
        }

        return $output;
    }
}