<?php

require_once("includes/config.php");
$action              = $_REQUEST['act'] ? $_REQUEST['act'] : 'list';
$page_menu           = "users";
$page_js             = 'users.js';

if (!$global->isLogged) {
    header('Location: ' . W_ROOT . 'account.php?act=sign-in');
    exit;
}

switch ($action) {
    // Display Users Listing page.
    case 'list':
        $can_see = $helper_obj->checkCanSee('users');
        if (!$can_see) {
            header('Location: ' . W_ROOT);
        }
        $page       = "user-list";
        $page_title = "Users";
        $post_data  = Utils::tidyPostValues($_POST);
        $users      = $user_obj->getAll($post_data);
        ?>
        <!-- Start: Content area -->
        <div class="row">
            <div class="col-md-12">
                <?php include F_PARTS . $page . '.php'; ?>
            </div>
        </div>
        <!-- End: Content area  -->

        <?php include(F_PARTS . "footer.php");
        break;

    // Display Add/Edit User Form.
    case 'edit-user':
        $page = "user-manage-form";
        $user_id     = $_POST['user_id'];
        $user_detail = $user_obj->getById($user_id);
        ?>
        <!-- Start: Content area -->
        <div class="row">
            <div class="col-md-12">
                <?php include F_PARTS . $page . '.php'; ?>
            </div>
        </div>
        <!-- End: Content area  -->
        <?php
        break;

    // Form Post for Add/Update User.
    case 'save-user':
        $post_data = Utils::tidyPostValues($_POST);
        $return    = array('success' => 0);
        $success   = $user_obj->save($post_data);
        break;

    // Ajax request to Delete User.
    case 'delete-user':
        $post_data = Utils::tidyPostValues($_POST);
        $return    = array('success' => 0);
        $success   = $user_obj->delete($post_data);
        if ($success) {
            $return = array('success' => 1);
        }
        echo json_encode($return);
        break;
}